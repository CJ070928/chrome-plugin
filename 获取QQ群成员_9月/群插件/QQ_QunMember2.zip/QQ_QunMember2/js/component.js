(function() {
    var srcPath = '../js/';
    document.write('<script src="' + srcPath + 'component/config.js"><\/script>');
    document.write('<script src="' + srcPath + 'component/event.js"><\/script>');
    document.write('<script src="' + srcPath + 'component/file.js"><\/script>');
    document.write('<script src="' + srcPath + 'component/resource.js"><\/script>');
    document.write('<script src="' + srcPath + 'component/rule.js"><\/script>');
}());
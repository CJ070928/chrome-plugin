(function() {
    var srcPath = '../js/';
    document.write('<script src="' + srcPath + 'lib/jquery.js"><\/script>');
    document.write('<script src="' + srcPath + 'lib/bootstrap.js"><\/script>');
    document.write('<script src="' + srcPath + 'lib/fiddler.js"><\/script>');
    document.write('<script src="' + srcPath + 'lib/when.js"><\/script>');
    document.write('<script src="' + srcPath + 'lib/base64.js"><\/script>');
    document.write('<script src="' + srcPath + 'lib/MimeTea.js"><\/script>');
    document.write('<script src="' + srcPath + 'lib/beautify/beautify_css.js"><\/script>');
    document.write('<script src="' + srcPath + 'lib/beautify/beautify_js.js"><\/script>');
    document.write('<script src="' + srcPath + 'lib/beautify/beautify_html.js"><\/script>');
    document.write('<script src="' + srcPath + 'lib/SyntaxHighlighter/shCore.js"><\/script>');
    document.write('<script src="' + srcPath + 'lib/SyntaxHighlighter/shBrushCss.js"><\/script>');
    document.write('<script src="' + srcPath + 'lib/SyntaxHighlighter/shBrushJScript.js"><\/script>');

}());
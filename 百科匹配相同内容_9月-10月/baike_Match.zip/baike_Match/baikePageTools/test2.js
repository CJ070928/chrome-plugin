var effectCode = {
    exact_match: {cls:"dup_exact_match", bk_color:"red"},
    high_match: {cls:"dup_high_match", bk_color:"red"},
    middle_match: {cls:"dup_middle_match", bk_color:"red"},
    low_match: {cls:"dup_low_match", bk_color:"red"}
}

console.log(effectCode.exact_match.bk_color);
$('#su').mouseover(function() {
	$(this).css('background-color','red');
	var test=$(this).val();
	console.log(test);
})
$('#su').mouseout(function() {
	$(this).css('background-color','#2d78f4');
})
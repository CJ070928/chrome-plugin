// http://tableizer.journalistopia.com/ 转table网址
$('.module_layer .module_categories a').click(function(){
   setTimeout(function(){
   	$('.edit_layer_wrap .module_title_wrap').append("<button id='openTable'>拉取全部字段</button>"); 
    $('.layer_content').before("<div id='pasteTable' contentEditable=true style=' overflow-y:scroll;width:100%;height:100px;background-color:#ddd'>&nbsp;</div>");
   },500);
})
var movieAppend='<li class="mod_content_wrap"><div class="movie_time"><div class="mod_input_wrap"><em>*</em><input type="text" name="time" class="input_content" placeholder="如:2010-01" rule="require,date" msg="如：2010-01" onblur="BaikeNew.module.onblur(this)" onfocus="BaikeNew.module.onfocus(this)" value=""></div></div><div class="movie_name"><div class="mod_input_wrap"><em>*</em><input type="text" name="name" class="input_content" placeholder="电影名称" rule="require" msg="请填写电影名称" onblur="BaikeNew.module.onblur(this)" onfocus="BaikeNew.module.onfocus(this)" value=""></div></div><div class="movie_role"><div class="mod_input_wrap"><em>*</em><input type="text" name="role" class="input_content" placeholder="角色名称" rule="require" msg="请填写角色名称" multi="3" value="" onblur="BaikeNew.module.onblur(this)" onfocus="BaikeNew.module.onfocus(this)"><a class="btn_add_item" title="增加项目" href="javascript:void(0)" onclick="BaikeNew.module.addInput(this);return false">增加</a></div></div><div class="movie_director"><div class="mod_input_wrap"><input type="text" name="director" class="input_content" placeholder="导演姓名" multi="3" value="" onblur="BaikeNew.module.onblur(this)" onfocus="BaikeNew.module.onfocus(this)"><a class="btn_add_item" title="增加项目" href="javascript:void(0)" onclick="BaikeNew.module.addInput(this);return false">增加</a></div></div><div class="movie_cast"><div class="mod_input_wrap"><input type="text" name="cast" class="input_content" placeholder="演员姓名" multi="3" value="" onblur="BaikeNew.module.onblur(this)" onfocus="BaikeNew.module.onfocus(this)"><a class="btn_add_item" title="增加项目" href="javascript:void(0)" onclick="BaikeNew.module.addInput(this);return false">增加</a></div></div><div class="btn_edit_wrap"><a class="btn_del_row" title="删除本行" href="javascript:void(0)" onclick="BaikeNew.module.deleteEditRow(this);return false">删除</a></div></li>'
var showAppend='<li class="mod_content_wrap"><div class="column1"><div class="mod_input_wrap"><em>*</em><input type="text" name="time" class="input_content" placeholder="如:2010-01" rule="date" msg="如：2010-01" onblur="BaikeNew.module.onblur(this)" onfocus="BaikeNew.module.onfocus(this)" value=""></div></div><div class="column2"><div class="mod_input_wrap"><em>*</em><input type="text" name="name" class="input_content" placeholder="节目名称" rule="require,maxlength" msg="请填写节目名称,不能超过20个字" onblur="BaikeNew.module.onblur(this)" onfocus="BaikeNew.module.onfocus(this)" value="" maxlength="20"></div></div><div class="column3"><div class="mod_input_wrap"><input type="text" name="platform" class="input_content" placeholder="播出平台" rule="maxlength" msg="不能超过20个字" maxlength="20" onblur="BaikeNew.module.onblur(this)" onfocus="BaikeNew.module.onfocus(this)" value=""></div></div><div class="column4"><div class="mod_input_wrap"><!-- <em>*</em> --><input type="text" name="description" class="input_content" placeholder="节目简介" rule="maxlength" msg="不能超过50个字" maxlength="50" onblur="BaikeNew.module.onblur(this)" onfocus="BaikeNew.module.onfocus(this)" value=""></div></div><div class="btn_edit_wrap"><a class="btn_move_up" title="向上移动" href="javascript:void(0)" onclick="BaikeNew.module.rowMoveup(this);return false">向上移动</a><a class="btn_move_down" title="向下移动" href="javascript:void(0)" onclick="BaikeNew.module.rowMovedown(this);return false">向下移动</a><a class="btn_del_row" title="删除本行" href="javascript:void(0)" onclick="BaikeNew.module.deleteEditRow(this);return false">删除</a></div></li>'
$(document).on('click','#openTable',function(){
	 var pasteTable=$('#pasteTable tbody tr');
	 var project=$(this).parent().find('h3')[0].innerText;

	  if (project=='电影作品'||project=='电视剧作品') {
		  	for (var i = 1; i < pasteTable.length; i++) { //遍历tr
		 	$(pasteTable[i]).childNodes;
		 	var tds=pasteTable[i].cells;
		 	if (i>1) {
		 		$('#edit_row_container').append(movieAppend);
		 	}
		 	var input=$('.input_list_wrap').find('li').eq(i-1)[0];	    
		 	for (var j = 0; j < tds.length; j++) {   // 获取每行tr的td里面的值
				var tdInner = tds[j].innerText.split('、'); 
				var testinput=$(input)[0].children[j];
				if (tdInner.length>1) { //当前个数大于1
	               var inputParent=$(testinput)[0];
	               console.log(inputParent);
	               for(var k=1;k<tdInner.length;k++){
					
		                if($(inputParent).hasClass('movie_cast')){//合作演员
		                	var movieCast='<div class="mod_input_wrap"><input type="text" name="cast" class="input_content" placeholder="演员姓名" multi="3" value="" onblur="BaikeNew.module.onblur(this)" onfocus="BaikeNew.module.onfocus(this)"></div>'
		                	$(inputParent).append(movieCast);
		                }else if($(inputParent).hasClass('movie_role')){//扮演角色
		                	var movieCast='<div class="mod_input_wrap"><em>*</em><input type="text" name="role" class="input_content" placeholder="角色名称" rule="require" msg="请填写角色名称" multi="3" value="" onblur="BaikeNew.module.onblur(this)" onfocus="BaikeNew.module.onfocus(this)"></div>'
		                	$(inputParent).append(movieCast);
		                }else if($(inputParent).hasClass('movie_director')){//导演
		                	var movieCast='<div class="mod_input_wrap"><input type="text" name="director" class="input_content" placeholder="导演姓名" multi="3" value="" onblur="BaikeNew.module.onblur(this)" onfocus="BaikeNew.module.onfocus(this)" oldph="导演姓名"></div>'
		                	$(inputParent).append(movieCast);
		                }
	               			
				   }
	               for(var k=0;k<tdInner.length;k++){
						 var thisInput=$(inputParent).find('input').eq(k)[0];
						 $(thisInput).val(tdInner[k]);
	               }
				}else{ //
					var currentInput=$(testinput).find('input')[0];
					$(currentInput).val(tdInner[0]);
				}	
			};
		 };
	  }else if (project=='综艺节目') {
	  	for (var i = 1; i < pasteTable.length; i++) { //遍历tr
		 	$(pasteTable[i]).childNodes;
		 	var tds=pasteTable[i].cells;
		 	if (i>1) {
		 		$('#edit_row_container').append(showAppend);
		 	}
		 	var input=$('.input_list_wrap').find('li').eq(i-1)[0];	    
		 	for (var j = 0; j < tds.length; j++) {   // 获取每行tr的td里面的值
				var tdInner = tds[j].innerText; 
				var testinput=$(input)[0].children[j];
				console.log(tdInner);
				var currentInput=$(testinput).find('input')[0];
				$(currentInput).val(tdInner);				
			};
		 };
	  }	 
})
